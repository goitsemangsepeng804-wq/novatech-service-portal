
// NOVATECH SOLUTIONS WEBSITE

console.log("NovaTech Solutions website loaded successfully.");


// ==================================================
// TICKET SUBMISSION
// ==================================================

const ticketForm = document.getElementById("ticketForm");

if (ticketForm) {
    ticketForm.addEventListener("submit", function (event) {
        event.preventDefault();

        if (!ticketForm.checkValidity()) {
            ticketForm.reportValidity();
            return;
        }

        let tickets = JSON.parse(localStorage.getItem("tickets")) || [];
        let ticketNumber = Number(localStorage.getItem("ticketNumber")) || 1;

        let incidentId = "INC-" + String(ticketNumber).padStart(3, "0");

        let now = new Date();

        let submissionDate =
            now.getFullYear() + "-" +
            String(now.getMonth() + 1).padStart(2, "0") + "-" +
            String(now.getDate()).padStart(2, "0");

        let ticket = {
            incidentId: incidentId,
            date: submissionDate,
            category: document.getElementById("category").value,
            priority: document.getElementById("priority").value,
            description: document.getElementById("description").value,
            technician: document.getElementById("technician").value,
            resolutionTime: "Not yet resolved",
            status: "Open"
        };

        tickets.push(ticket);

        localStorage.setItem("tickets", JSON.stringify(tickets));
        localStorage.setItem("ticketNumber", ticketNumber + 1);

        const confirmation = document.getElementById("confirmation");

        confirmation.innerHTML =
            "<h3>Ticket Submitted Successfully!</h3>" +
            "<p>Your Incident ID is: <strong>" + incidentId + "</strong></p>" +
            "<p>Current Status: <strong>Open</strong></p>";

        confirmation.style.display = "block";

        ticketForm.reset();

        document.getElementById("incidentId").value =
            "Automatically generated";

        confirmation.scrollIntoView({ behavior: "smooth" });
    });
}


// ==================================================
// ADMIN ACCESS
// ==================================================

function openAdminLogin() {
    const adminLogin = document.getElementById("adminLogin");

    if (adminLogin) {
        adminLogin.style.display = "block";
        adminLogin.scrollIntoView({ behavior: "smooth" });
    }
}

const adminButton = document.getElementById("adminButton");

if (adminButton) {
    adminButton.addEventListener("click", openAdminLogin);
}


// ==================================================
// ADMIN LOGIN
// ==================================================

function adminLoginCheck() {
    const usernameElement = document.getElementById("adminUsername");
    const passwordElement = document.getElementById("adminPassword");
    const loginMessage = document.getElementById("loginMessage");
    const adminSection = document.getElementById("adminSection");

    if (!usernameElement || !passwordElement || !loginMessage || !adminSection) {
        console.error("Admin login elements could not be found.");
        return;
    }

    const username = usernameElement.value.trim();
    const password = passwordElement.value;

    if (username === "admin" && password === "NovaTech2026") {
        loginMessage.textContent = "Login successful!";
        loginMessage.style.color = "green";

        adminSection.style.display = "block";

        displayTickets();

        adminSection.scrollIntoView({ behavior: "smooth" });

    } else {
        loginMessage.textContent = "Invalid username or password.";
        loginMessage.style.color = "red";

        adminSection.style.display = "none";
    }
}

const loginButton = document.getElementById("loginButton");

if (loginButton) {
    loginButton.addEventListener("click", adminLoginCheck);
}


// ==================================================
// DISPLAY TICKETS WITH COLOUR-CODED PRIORITY/STATUS
// ==================================================

function displayTickets(selectedDate = null) {
    const tickets = JSON.parse(localStorage.getItem("tickets")) || [];

    const tableBody = document.getElementById("ticketTableBody");

    if (!tableBody) {
        return;
    }

    tableBody.innerHTML = "";

    let filteredTickets = tickets;

    if (selectedDate) {
        filteredTickets = tickets.filter(function (ticket) {
            return ticket.date === selectedDate;
        });
    }

    if (filteredTickets.length === 0) {
        tableBody.innerHTML =
            '<tr><td colspan="7" style="text-align:center; padding:20px;">' +
            "No tickets found." +
            "</td></tr>";

        return;
    }

    filteredTickets.forEach(function (ticket) {
        const row = document.createElement("tr");

        const values = [
            ticket.incidentId,
            ticket.category,
            ticket.priority,
            ticket.description,
            ticket.technician,
            ticket.resolutionTime,
            ticket.status
        ];

        values.forEach(function (value, index) {
            const cell = document.createElement("td");

            cell.textContent = value || "";
            cell.style.padding = "12px";
            cell.style.border = "1px solid #ddd";

            // PRIORITY COLOURS
            if (index === 2) {
                if (value === "High") {
                    cell.style.backgroundColor = "#f8d7da";
                    cell.style.color = "#842029";

                } else if (value === "Medium") {
                    cell.style.backgroundColor = "#fff3cd";
                    cell.style.color = "#664d03";

                } else if (value === "Low") {
                    cell.style.backgroundColor = "#d1e7dd";
                    cell.style.color = "#0f5132";
                }
            }

            // STATUS COLOURS
            if (index === 6) {
                if (value === "Resolved") {
                    cell.style.backgroundColor = "#d1e7dd";
                    cell.style.color = "#0f5132";

                } else if (value === "Open") {
                    cell.style.backgroundColor = "#cfe2ff";
                    cell.style.color = "#084298";

                } else if (value === "Pending") {
                    cell.style.backgroundColor = "#fff3cd";
                    cell.style.color = "#664d03";
                }
            }

            row.appendChild(cell);
        });

        tableBody.appendChild(row);
    });
}


// ==================================================
// FILTER TICKETS BY DATE
// ==================================================

const viewTicketsBtn = document.getElementById("viewTicketsBtn");

if (viewTicketsBtn) {
    viewTicketsBtn.addEventListener("click", function (event) {
        event.preventDefault();

        const dateInput = document.getElementById("ticketDate");
        const selectedDate = dateInput.value;

        if (!selectedDate) {
            alert("Please select a date.");
            return;
        }

        displayTickets(selectedDate);
    });
}


// ==================================================
// SHOW ALL TICKETS
// ==================================================

const showAllBtn = document.getElementById("showAllBtn");

if (showAllBtn) {
    showAllBtn.addEventListener("click", function (event) {
        event.preventDefault();

        document.getElementById("ticketDate").value = "";

        displayTickets();
    });
}


// ==================================================
// CHANGE REQUEST FORM
// ==================================================

const changeForm = document.getElementById("changeForm");

if (changeForm) {
    changeForm.addEventListener("submit", function (event) {
        event.preventDefault();

        if (!changeForm.checkValidity()) {
            changeForm.reportValidity();
            return;
        }

        const changeSuccess = document.getElementById("changeSuccess");

        if (changeSuccess) {
            changeSuccess.style.display = "block";
            changeSuccess.scrollIntoView({ behavior: "smooth" });
        }

        changeForm.reset();
    });
}


// ==================================================
// MAKE ADMIN FUNCTIONS AVAILABLE TO HTML
// ==================================================

window.adminLoginCheck = adminLoginCheck;
window.openAdminLogin = openAdminLogin;

